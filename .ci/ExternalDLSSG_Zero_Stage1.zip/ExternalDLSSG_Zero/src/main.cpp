#include <windows.h>
#include <wrl/client.h>
#include <d3d12.h>
#include <dxgi1_6.h>
#include <DirectXMath.h>

#include <sl.h>
#include <sl_consts.h>
#include <sl_dlss_g.h>
#include <sl_reflex.h>
#include <sl_pcl.h>

#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <mutex>
#include <sstream>
#include <string>
#include <vector>

using Microsoft::WRL::ComPtr;

namespace {

std::mutex g_logMutex;
std::ofstream g_log;
std::atomic<long> g_lastPresentHr{S_OK};

std::wstring ExeDir() {
    wchar_t buf[32768]{};
    DWORD n = GetModuleFileNameW(nullptr, buf, static_cast<DWORD>(std::size(buf)));
    return std::filesystem::path(std::wstring(buf, n)).parent_path().wstring();
}

std::string Narrow(const std::wstring& s) {
    if (s.empty()) return {};
    int n = WideCharToMultiByte(CP_UTF8, 0, s.c_str(), static_cast<int>(s.size()), nullptr, 0, nullptr, nullptr);
    std::string out(static_cast<size_t>(n), '\0');
    WideCharToMultiByte(CP_UTF8, 0, s.c_str(), static_cast<int>(s.size()), out.data(), n, nullptr, nullptr);
    return out;
}

void Log(const std::string& s) {
    std::lock_guard lock(g_logMutex);
    SYSTEMTIME st{}; GetLocalTime(&st);
    if (g_log.is_open()) {
        g_log << '[' << st.wHour << ':' << st.wMinute << ':' << st.wSecond << '.' << st.wMilliseconds << "] " << s << "\n";
        g_log.flush();
    }
    OutputDebugStringA((s + "\n").c_str());
}

std::string Hr(HRESULT hr) {
    std::ostringstream o; o << "0x" << std::hex << std::uppercase << static_cast<uint32_t>(hr); return o.str();
}

void SlLog(sl::LogType type, const char* msg) {
    const char* p = type == sl::LogType::eError ? "SL ERROR: " : type == sl::LogType::eWarn ? "SL WARN: " : "SL: ";
    Log(std::string(p) + (msg ? msg : ""));
}

void SlApiError(const sl::APIError& e) {
    g_lastPresentHr.store(static_cast<long>(e.hres), std::memory_order_relaxed);
}

bool SlOK(sl::Result r, const char* where) {
    if (r == sl::Result::eOk) return true;
    Log(std::string(where) + " failed: " + sl::getResultAsStr(r));
    return false;
}

sl::float4x4 ToSL(const DirectX::XMFLOAT4X4& m) {
    sl::float4x4 out{};
    out.row[0] = {m._11,m._12,m._13,m._14};
    out.row[1] = {m._21,m._22,m._23,m._24};
    out.row[2] = {m._31,m._32,m._33,m._34};
    out.row[3] = {m._41,m._42,m._43,m._44};
    return out;
}

sl::float4x4 IdentitySL() {
    DirectX::XMFLOAT4X4 m{};
    DirectX::XMStoreFloat4x4(&m, DirectX::XMMatrixIdentity());
    return ToSL(m);
}

struct App {
    HINSTANCE inst{};
    HWND hwnd{};
    std::wstring exeDir;
    std::wstring logDir;
    bool slInitialized{};
    bool featureReady{};
    bool running{true};
    uint32_t width{1280}, height{720};
    uint32_t requestedMultiplier{2};
    uint32_t maxGenerated{1};
    sl::ViewportHandle viewport{0};
    uint64_t frameIndex{};

    ComPtr<IDXGIFactory6> factory;
    ComPtr<IDXGIAdapter1> adapter;
    ComPtr<ID3D12Device> device;
    ComPtr<ID3D12CommandQueue> queue;
    ComPtr<IDXGISwapChain3> swapchain;
    static constexpr UINT kBuffers = 2;
    std::array<ComPtr<ID3D12Resource>, kBuffers> backbuffers;
    ComPtr<ID3D12DescriptorHeap> rtvHeap;
    UINT rtvInc{};
    ComPtr<ID3D12CommandAllocator> allocator;
    ComPtr<ID3D12GraphicsCommandList> cmd;
    ComPtr<ID3D12Fence> fence;
    HANDLE fenceEvent{};
    uint64_t fenceValue{};

    ComPtr<ID3D12Resource> depth;
    ComPtr<ID3D12DescriptorHeap> dsvHeap;
    ComPtr<ID3D12Resource> motion;
    ComPtr<ID3D12DescriptorHeap> uavHeap;
    ComPtr<ID3D12Resource> hudless;
    ComPtr<ID3D12Resource> uiAlpha;
    ComPtr<ID3D12DescriptorHeap> auxRtvHeap;

    ~App() { Shutdown(); }

    static LRESULT CALLBACK WndProc(HWND h, UINT m, WPARAM w, LPARAM l) {
        App* self = reinterpret_cast<App*>(GetWindowLongPtrW(h, GWLP_USERDATA));
        if (m == WM_NCCREATE) {
            auto* cs = reinterpret_cast<CREATESTRUCTW*>(l);
            self = reinterpret_cast<App*>(cs->lpCreateParams);
            SetWindowLongPtrW(h, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(self));
        }
        switch (m) {
        case WM_CLOSE: DestroyWindow(h); return 0;
        case WM_DESTROY: PostQuitMessage(0); return 0;
        case WM_SIZE:
            if (self && w != SIZE_MINIMIZED) {
                self->width = LOWORD(l); self->height = HIWORD(l);
            }
            return 0;
        case WM_KEYDOWN:
            if (self) {
                if (w >= '2' && w <= '6') self->requestedMultiplier = static_cast<uint32_t>(w - '0');
                if (w == VK_ESCAPE) DestroyWindow(h);
            }
            return 0;
        }
        return DefWindowProcW(h,m,w,l);
    }

    bool CreateWindowUI() {
        WNDCLASSEXW wc{sizeof(wc)};
        wc.lpfnWndProc = &WndProc; wc.hInstance = inst; wc.lpszClassName = L"ExternalDLSSGZeroWindow";
        wc.hCursor = LoadCursor(nullptr, IDC_ARROW); wc.hbrBackground = reinterpret_cast<HBRUSH>(COLOR_WINDOW+1);
        if (!RegisterClassExW(&wc) && GetLastError() != ERROR_CLASS_ALREADY_EXISTS) return false;
        RECT r{0,0,static_cast<LONG>(width),static_cast<LONG>(height)};
        AdjustWindowRect(&r, WS_OVERLAPPEDWINDOW, FALSE);
        hwnd = CreateWindowExW(0,wc.lpszClassName,L"External DLSS-G — Zero Build",WS_OVERLAPPEDWINDOW|WS_VISIBLE,
            CW_USEDEFAULT,CW_USEDEFAULT,r.right-r.left,r.bottom-r.top,nullptr,nullptr,inst,this);
        return hwnd != nullptr;
    }

    bool InitSL() {
        std::filesystem::create_directories(logDir);
        sl::Feature features[] = { sl::kFeatureDLSS_G, sl::kFeatureReflex, sl::kFeaturePCL };
        const wchar_t* pluginPaths[] = { exeDir.c_str() };
        sl::Preferences p{};
        p.showConsole = false;
        p.logLevel = sl::LogLevel::eVerbose;
        p.logMessageCallback = &SlLog;
        p.pathsToPlugins = pluginPaths;
        p.numPathsToPlugins = 1;
        p.pathToLogsAndData = logDir.c_str();
        p.featuresToLoad = features;
        p.numFeaturesToLoad = static_cast<uint32_t>(std::size(features));
        p.applicationId = 0;
        p.engine = sl::EngineType::eCustom;
        p.engineVersion = "1.0.0";
        p.projectId = "566b8148-8d0a-4f42-a46e-2dbf2a3d8fd1";
        p.renderAPI = sl::RenderAPI::eD3D12;
        p.flags |= sl::PreferenceFlags::eUseFrameBasedResourceTagging;
        if (!SlOK(slInit(p, sl::kSDKVersion), "slInit")) return false;
        slInitialized = true;
        Log("Streamline initialized before any DXGI/D3D calls");
        return true;
    }

    bool PickAdapterAndCreateDevice() {
        HRESULT hr = CreateDXGIFactory2(0, IID_PPV_ARGS(&factory));
        if (FAILED(hr)) { Log("CreateDXGIFactory2 failed " + Hr(hr)); return false; }

        sl::FeatureRequirements req{};
        SlOK(slGetFeatureRequirements(sl::kFeatureDLSS_G, req), "slGetFeatureRequirements(DLSS-G)");

        SIZE_T bestMem = 0;
        for (UINT i=0;;++i) {
            ComPtr<IDXGIAdapter1> a;
            if (factory->EnumAdapters1(i,&a) == DXGI_ERROR_NOT_FOUND) break;
            DXGI_ADAPTER_DESC1 d{}; a->GetDesc1(&d);
            sl::AdapterInfo ai{}; ai.deviceLUID = reinterpret_cast<uint8_t*>(&d.AdapterLuid); ai.deviceLUIDSizeInBytes = sizeof(d.AdapterLuid);
            auto sr = slIsFeatureSupported(sl::kFeatureDLSS_G, ai);
            Log("Adapter " + std::to_string(i) + " " + Narrow(d.Description) + " DLSS-G=" + sl::getResultAsStr(sr));
            if (sr == sl::Result::eOk && d.DedicatedVideoMemory >= bestMem) { bestMem = d.DedicatedVideoMemory; adapter = a; }
        }
        if (!adapter) { Log("No adapter reports DLSS-G support"); return false; }

        hr = D3D12CreateDevice(adapter.Get(), D3D_FEATURE_LEVEL_12_0, IID_PPV_ARGS(&device));
        if (FAILED(hr)) { Log("D3D12CreateDevice failed " + Hr(hr)); return false; }
        if (!SlOK(slSetD3DDevice(device.Get()), "slSetD3DDevice")) return false;
        Log("D3D12 device created through Streamline interposer and assigned to SL");

        D3D12_COMMAND_QUEUE_DESC qd{}; qd.Type = D3D12_COMMAND_LIST_TYPE_DIRECT;
        hr = device->CreateCommandQueue(&qd, IID_PPV_ARGS(&queue));
        if (FAILED(hr)) { Log("CreateCommandQueue failed " + Hr(hr)); return false; }

        sl::ReflexOptions ro{}; ro.mode = sl::ReflexMode::eLowLatency; ro.frameLimitUs = 0; ro.useMarkersToOptimize = false;
        if (!SlOK(slReflexSetOptions(ro), "slReflexSetOptions")) return false;
        sl::PCLOptions po{}; po.virtualKey = sl::PCLHotKey::eVK_F13;
        SlOK(slPCLSetOptions(po), "slPCLSetOptions");
        return true;
    }

    bool CreateSwapchainAndResources() {
        if (!SlOK(slSetFeatureLoaded(sl::kFeatureDLSS_G, true), "slSetFeatureLoaded(DLSS-G,true)")) return false;
        DXGI_SWAP_CHAIN_DESC1 sd{};
        sd.Width=width; sd.Height=height; sd.Format=DXGI_FORMAT_B8G8R8A8_UNORM; sd.SampleDesc.Count=1;
        sd.BufferUsage=DXGI_USAGE_RENDER_TARGET_OUTPUT; sd.BufferCount=kBuffers; sd.SwapEffect=DXGI_SWAP_EFFECT_FLIP_DISCARD;
        sd.Flags=DXGI_SWAP_CHAIN_FLAG_ALLOW_TEARING;
        ComPtr<IDXGISwapChain1> s1;
        HRESULT hr = factory->CreateSwapChainForHwnd(queue.Get(), hwnd, &sd, nullptr, nullptr, &s1);
        if (FAILED(hr)) { Log("CreateSwapChainForHwnd failed " + Hr(hr)); return false; }
        hr=s1.As(&swapchain); if(FAILED(hr)){Log("Swapchain QI failed " + Hr(hr));return false;}
        factory->MakeWindowAssociation(hwnd, DXGI_MWA_NO_ALT_ENTER);

        D3D12_DESCRIPTOR_HEAP_DESC rh{}; rh.Type=D3D12_DESCRIPTOR_HEAP_TYPE_RTV; rh.NumDescriptors=kBuffers;
        if(FAILED(device->CreateDescriptorHeap(&rh,IID_PPV_ARGS(&rtvHeap)))) return false;
        rtvInc=device->GetDescriptorHandleIncrementSize(D3D12_DESCRIPTOR_HEAP_TYPE_RTV);
        auto rtv=rtvHeap->GetCPUDescriptorHandleForHeapStart();
        for(UINT i=0;i<kBuffers;++i){
            if(FAILED(swapchain->GetBuffer(i,IID_PPV_ARGS(&backbuffers[i])))) return false;
            device->CreateRenderTargetView(backbuffers[i].Get(),nullptr,rtv); rtv.ptr+=rtvInc;
        }
        if(FAILED(device->CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_DIRECT,IID_PPV_ARGS(&allocator)))) return false;
        if(FAILED(device->CreateCommandList(0,D3D12_COMMAND_LIST_TYPE_DIRECT,allocator.Get(),nullptr,IID_PPV_ARGS(&cmd)))) return false;
        cmd->Close();
        if(FAILED(device->CreateFence(0,D3D12_FENCE_FLAG_NONE,IID_PPV_ARGS(&fence)))) return false;
        fenceEvent=CreateEventW(nullptr,FALSE,FALSE,nullptr); if(!fenceEvent)return false;

        D3D12_HEAP_PROPERTIES hp{}; hp.Type=D3D12_HEAP_TYPE_DEFAULT;
        D3D12_RESOURCE_DESC td{}; td.Dimension=D3D12_RESOURCE_DIMENSION_TEXTURE2D; td.Width=width; td.Height=height; td.DepthOrArraySize=1; td.MipLevels=1; td.SampleDesc.Count=1; td.Layout=D3D12_TEXTURE_LAYOUT_UNKNOWN;

        td.Format=DXGI_FORMAT_D32_FLOAT; td.Flags=D3D12_RESOURCE_FLAG_ALLOW_DEPTH_STENCIL;
        D3D12_CLEAR_VALUE dcv{}; dcv.Format=DXGI_FORMAT_D32_FLOAT; dcv.DepthStencil.Depth=1.0f;
        if(FAILED(device->CreateCommittedResource(&hp,D3D12_HEAP_FLAG_NONE,&td,D3D12_RESOURCE_STATE_DEPTH_WRITE,&dcv,IID_PPV_ARGS(&depth)))) return false;
        D3D12_DESCRIPTOR_HEAP_DESC dh{};dh.Type=D3D12_DESCRIPTOR_HEAP_TYPE_DSV;dh.NumDescriptors=1;
        if(FAILED(device->CreateDescriptorHeap(&dh,IID_PPV_ARGS(&dsvHeap)))) return false;
        device->CreateDepthStencilView(depth.Get(),nullptr,dsvHeap->GetCPUDescriptorHandleForHeapStart());

        td.Format=DXGI_FORMAT_R16G16_FLOAT; td.Flags=D3D12_RESOURCE_FLAG_ALLOW_UNORDERED_ACCESS;
        if(FAILED(device->CreateCommittedResource(&hp,D3D12_HEAP_FLAG_NONE,&td,D3D12_RESOURCE_STATE_UNORDERED_ACCESS,nullptr,IID_PPV_ARGS(&motion)))) return false;
        D3D12_DESCRIPTOR_HEAP_DESC uh{}; uh.Type=D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV; uh.NumDescriptors=1; uh.Flags=D3D12_DESCRIPTOR_HEAP_FLAG_SHADER_VISIBLE;
        if(FAILED(device->CreateDescriptorHeap(&uh,IID_PPV_ARGS(&uavHeap)))) return false;
        D3D12_UNORDERED_ACCESS_VIEW_DESC uv{};uv.Format=DXGI_FORMAT_R16G16_FLOAT;uv.ViewDimension=D3D12_UAV_DIMENSION_TEXTURE2D;
        device->CreateUnorderedAccessView(motion.Get(),nullptr,&uv,uavHeap->GetCPUDescriptorHandleForHeapStart());

        D3D12_DESCRIPTOR_HEAP_DESC ar{}; ar.Type=D3D12_DESCRIPTOR_HEAP_TYPE_RTV; ar.NumDescriptors=2;
        if(FAILED(device->CreateDescriptorHeap(&ar,IID_PPV_ARGS(&auxRtvHeap)))) return false;
        auto aux=auxRtvHeap->GetCPUDescriptorHandleForHeapStart();
        td.Format=DXGI_FORMAT_B8G8R8A8_UNORM;td.Flags=D3D12_RESOURCE_FLAG_ALLOW_RENDER_TARGET;
        D3D12_CLEAR_VALUE ccv{};ccv.Format=DXGI_FORMAT_B8G8R8A8_UNORM;
        if(FAILED(device->CreateCommittedResource(&hp,D3D12_HEAP_FLAG_NONE,&td,D3D12_RESOURCE_STATE_RENDER_TARGET,&ccv,IID_PPV_ARGS(&hudless)))) return false;
        device->CreateRenderTargetView(hudless.Get(),nullptr,aux); aux.ptr+=rtvInc;
        td.Format=DXGI_FORMAT_R8_UNORM; ccv.Format=DXGI_FORMAT_R8_UNORM;
        if(FAILED(device->CreateCommittedResource(&hp,D3D12_HEAP_FLAG_NONE,&td,D3D12_RESOURCE_STATE_RENDER_TARGET,&ccv,IID_PPV_ARGS(&uiAlpha)))) return false;
        D3D12_RENDER_TARGET_VIEW_DESC urtv{};urtv.Format=DXGI_FORMAT_R8_UNORM;urtv.ViewDimension=D3D12_RTV_DIMENSION_TEXTURE2D;
        device->CreateRenderTargetView(uiAlpha.Get(),&urtv,aux);

        Log("Swapchain and required DLSS-G input resources created");
        return true;
    }

    void WaitGPU() {
        if(!queue||!fence)return;
        const uint64_t v=++fenceValue; queue->Signal(fence.Get(),v);
        if(fence->GetCompletedValue()<v){fence->SetEventOnCompletion(v,fenceEvent);WaitForSingleObject(fenceEvent,INFINITE);}    
    }

    bool RenderFrame() {
        sl::FrameToken* token{};
        uint32_t fi=static_cast<uint32_t>(frameIndex);
        if(!SlOK(slGetNewFrameToken(token,&fi),"slGetNewFrameToken")) return false;

        SlOK(slReflexSleep(*token),"slReflexSleep");
        SlOK(slPCLSetMarker(sl::PCLMarker::eSimulationStart,*token),"PCL SimulationStart");
        SlOK(slPCLSetMarker(sl::PCLMarker::eSimulationEnd,*token),"PCL SimulationEnd");

        UINT idx=swapchain->GetCurrentBackBufferIndex();
        if(FAILED(allocator->Reset()))return false;
        if(FAILED(cmd->Reset(allocator.Get(),nullptr)))return false;

        D3D12_RESOURCE_BARRIER b{};b.Type=D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;b.Transition.pResource=backbuffers[idx].Get();b.Transition.StateBefore=D3D12_RESOURCE_STATE_PRESENT;b.Transition.StateAfter=D3D12_RESOURCE_STATE_RENDER_TARGET;b.Transition.Subresource=D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
        cmd->ResourceBarrier(1,&b);
        auto rtv=rtvHeap->GetCPUDescriptorHandleForHeapStart();rtv.ptr+=static_cast<SIZE_T>(idx)*rtvInc;
        float t=float((frameIndex%300)/300.0); float color[4]{0.05f+0.15f*t,0.08f,0.12f+0.1f*(1.0f-t),1.0f};
        cmd->ClearRenderTargetView(rtv,color,0,nullptr);
        auto aux=auxRtvHeap->GetCPUDescriptorHandleForHeapStart();cmd->ClearRenderTargetView(aux,color,0,nullptr);aux.ptr+=rtvInc;
        float zero[4]{};cmd->ClearRenderTargetView(aux,zero,0,nullptr);
        cmd->ClearDepthStencilView(dsvHeap->GetCPUDescriptorHandleForHeapStart(),D3D12_CLEAR_FLAG_DEPTH,1.0f,0,0,nullptr);
        ID3D12DescriptorHeap* heaps[]={uavHeap.Get()};cmd->SetDescriptorHeaps(1,heaps);
        float z4[4]{};cmd->ClearUnorderedAccessViewFloat(uavHeap->GetGPUDescriptorHandleForHeapStart(),uavHeap->GetCPUDescriptorHandleForHeapStart(),motion.Get(),z4,0,nullptr);

        DirectX::XMMATRIX p=DirectX::XMMatrixPerspectiveFovLH(DirectX::XM_PIDIV2,float(width)/float(height),0.1f,1000.0f);
        DirectX::XMVECTOR det{};DirectX::XMMATRIX ip=DirectX::XMMatrixInverse(&det,p);
        DirectX::XMFLOAT4X4 pf{},ipf{};DirectX::XMStoreFloat4x4(&pf,p);DirectX::XMStoreFloat4x4(&ipf,ip);
        sl::Constants c{};c.cameraViewToClip=ToSL(pf);c.clipToCameraView=ToSL(ipf);c.clipToLensClip=IdentitySL();c.clipToPrevClip=IdentitySL();c.prevClipToClip=IdentitySL();
        c.jitterOffset={0,0};c.mvecScale={1.0f/float(width),1.0f/float(height)};c.cameraPinholeOffset={0,0};c.cameraPos={0,0,0};c.cameraUp={0,1,0};c.cameraRight={1,0,0};c.cameraFwd={0,0,1};
        c.cameraNear=0.1f;c.cameraFar=1000.0f;c.cameraFOV=DirectX::XM_PIDIV2;c.cameraAspectRatio=float(width)/float(height);c.depthInverted=sl::Boolean::eFalse;c.cameraMotionIncluded=sl::Boolean::eTrue;c.motionVectors3D=sl::Boolean::eFalse;c.reset=frameIndex==0?sl::Boolean::eTrue:sl::Boolean::eFalse;
        c.orthographicProjection=sl::Boolean::eFalse;c.motionVectorsDilated=sl::Boolean::eFalse;c.motionVectorsJittered=sl::Boolean::eFalse;
        if(!SlOK(slSetConstants(c,*token,viewport),"slSetConstants"))return false;

        sl::Extent ext{0,0,width,height};
        sl::Resource dres{sl::ResourceType::eTex2d,depth.Get(),static_cast<uint32_t>(D3D12_RESOURCE_STATE_DEPTH_WRITE)};
        sl::Resource mres{sl::ResourceType::eTex2d,motion.Get(),static_cast<uint32_t>(D3D12_RESOURCE_STATE_UNORDERED_ACCESS)};
        sl::Resource hres{sl::ResourceType::eTex2d,hudless.Get(),static_cast<uint32_t>(D3D12_RESOURCE_STATE_RENDER_TARGET)};
        sl::Resource ures{sl::ResourceType::eTex2d,uiAlpha.Get(),static_cast<uint32_t>(D3D12_RESOURCE_STATE_RENDER_TARGET)};
        sl::ResourceTag tags[] = {
            {&dres,sl::kBufferTypeDepth,sl::ResourceLifecycle::eValidUntilPresent,&ext},
            {&mres,sl::kBufferTypeMotionVectors,sl::ResourceLifecycle::eValidUntilPresent,&ext},
            {&hres,sl::kBufferTypeHUDLessColor,sl::ResourceLifecycle::eValidUntilPresent,&ext},
            {&ures,sl::kBufferTypeUIAlpha,sl::ResourceLifecycle::eValidUntilPresent,&ext}
        };
        if(!SlOK(slSetTagForFrame(*token,viewport,tags,static_cast<uint32_t>(std::size(tags)),reinterpret_cast<sl::CommandBuffer*>(cmd.Get())),"slSetTagForFrame"))return false;

        sl::DLSSGOptions opt{};opt.mode=sl::DLSSGMode::eOn;opt.numFramesToGenerate=(requestedMultiplier>0?requestedMultiplier-1:1);opt.numBackBuffers=kBuffers;opt.mvecDepthWidth=width;opt.mvecDepthHeight=height;opt.colorWidth=width;opt.colorHeight=height;
        opt.colorBufferFormat=DXGI_FORMAT_B8G8R8A8_UNORM;opt.mvecBufferFormat=DXGI_FORMAT_R16G16_FLOAT;opt.depthBufferFormat=DXGI_FORMAT_D32_FLOAT;opt.hudLessBufferFormat=DXGI_FORMAT_B8G8R8A8_UNORM;opt.uiBufferFormat=DXGI_FORMAT_R8_UNORM;opt.onErrorCallback=&SlApiError;opt.enableUserInterfaceRecomposition=sl::Boolean::eTrue;
        sl::DLSSGState state{};if(SlOK(slDLSSGGetState(viewport,state,&opt),"slDLSSGGetState")){maxGenerated=state.numFramesToGenerateMax; if(opt.numFramesToGenerate>maxGenerated)opt.numFramesToGenerate=maxGenerated;}
        if(!SlOK(slDLSSGSetOptions(viewport,opt),"slDLSSGSetOptions"))return false;

        b.Transition.StateBefore=D3D12_RESOURCE_STATE_RENDER_TARGET;b.Transition.StateAfter=D3D12_RESOURCE_STATE_PRESENT;cmd->ResourceBarrier(1,&b);
        if(FAILED(cmd->Close()))return false;
        ID3D12CommandList* lists[]={cmd.Get()};
        SlOK(slPCLSetMarker(sl::PCLMarker::eRenderSubmitStart,*token),"PCL RenderSubmitStart");
        queue->ExecuteCommandLists(1,lists);
        SlOK(slPCLSetMarker(sl::PCLMarker::eRenderSubmitEnd,*token),"PCL RenderSubmitEnd");
        SlOK(slPCLSetMarker(sl::PCLMarker::ePresentStart,*token),"PCL PresentStart");
        HRESULT phr=swapchain->Present(0,DXGI_PRESENT_ALLOW_TEARING);
        SlOK(slPCLSetMarker(sl::PCLMarker::ePresentEnd,*token),"PCL PresentEnd");
        if(FAILED(phr)){Log("Present failed " + Hr(phr));return false;}
        long asyncHr=g_lastPresentHr.exchange(S_OK);if(FAILED(asyncHr)){Log("DLSS-G async present error "+Hr(asyncHr));return false;}
        WaitGPU();
        ++frameIndex;
        return true;
    }

    bool Init(HINSTANCE h) {
        inst=h;exeDir=ExeDir();logDir=(std::filesystem::path(exeDir)/L"logs").wstring();std::filesystem::create_directories(logDir);
        g_log.open(std::filesystem::path(logDir)/L"ExternalDLSSG-Zero.log",std::ios::out|std::ios::trunc);
        Log("=== ExternalDLSSG Zero clean start ===");
        if(!CreateWindowUI()){Log("Window creation failed");return false;}
        if(!InitSL())return false;
        if(!PickAdapterAndCreateDevice())return false;
        if(!CreateSwapchainAndResources())return false;
        featureReady=true;return true;
    }

    int Run() {
        MSG msg{};
        while(running){
            while(PeekMessageW(&msg,nullptr,0,0,PM_REMOVE)){if(msg.message==WM_QUIT){running=false;break;}TranslateMessage(&msg);DispatchMessageW(&msg);}if(!running)break;
            if(featureReady){if(!RenderFrame()){featureReady=false;SetWindowTextW(hwnd,L"External DLSS-G — initialization/render error; see logs");Sleep(50);}}
            else Sleep(16);
        }
        return 0;
    }

    void Shutdown(){
        if(queue&&fence)WaitGPU();
        if(slInitialized){slDLSSGSetOptions(viewport,sl::DLSSGOptions{});slShutdown();slInitialized=false;}
        if(fenceEvent){CloseHandle(fenceEvent);fenceEvent=nullptr;}
        if(g_log.is_open()){Log("Shutdown complete");g_log.close();}
    }
};

}

int WINAPI wWinMain(HINSTANCE h,HINSTANCE,LPWSTR,int){
    App app;
    if(!app.Init(h)){
        MessageBoxW(nullptr,L"Clean Streamline/D3D12 initialization failed. See logs\\ExternalDLSSG-Zero.log.",L"External DLSS-G — startup failed",MB_OK|MB_ICONERROR);
        return 2;
    }
    return app.Run();
}
